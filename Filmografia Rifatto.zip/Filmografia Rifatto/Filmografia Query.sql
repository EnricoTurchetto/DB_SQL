USE
	filmografia;


-- Nomi dei registi che hanno diretto nel 2022 meno film di quanti ne avevano diretti nel 2021

WITH
	a_2021
    AS (
		SELECT 										-- Conteggio dei film diretti nel 2021
			regista_id,
            count(titolo) AS N_film
		FROM
            film 
		WHERE
			anno = 2021
		GROUP BY
			regista_id
		),
	a_2022
    AS (
		SELECT 										-- Conteggio dei film diretti nel 2022
			regista_id,
            count(titolo) AS N_film
		FROM
            film
		WHERE
			anno = 2022
		GROUP BY
			regista_id
		)
SELECT 
	r.nome
FROM 
	regista r
    JOIN
	a_2021 AS a21 ON a21.regista_id = r.regista_id
	JOIN														-- Inner join perché interessano solo i registi che hanno diretto sia nel 2021 che nel 2022
	a_2022 AS a22 ON a21.regista_id = a22.regista_id			-- non si considerano i casi in cui i registi non hanno diretto nessun film nel 2022
WHERE
	a22.N_film < a21.N_film;									-- Confronto tra i due conteggi



-- Le date di nascita dei registi che hanno diretto film in proiezione sia a Monza sia a Treviso

SELECT
	DISTINCT datanascita
FROM 
	regista
WHERE
	regista_id
	IN (
    SELECT 										-- Selezione dei registi che hanno diretto film in proiezione a Monza
		DISTINCT f.regista_id
	FROM 
		film f
		JOIN 
        proiezione p USING (film_id)
        JOIN
        cinema c USING (cinema_id)
	WHERE 
		c.città = 'Monza'
	)
    AND
    regista_id IN (
	SELECT 										-- Selezione dei registi che hanno diretto film in proiezione a Treviso
		DISTINCT f.regista_id
	FROM 
		film f
		JOIN 
		proiezione p USING (film_id)
		JOIN
		cinema c USING (cinema_id)
	WHERE 
		c.città = 'Treviso'
	);
	


-- Film proiettato più volte nei cinema di Milano

SELECT
	f.titolo,
    COUNT(p.film_id) AS N_proiezioni
FROM
	proiezione p
	JOIN
    cinema c USING (cinema_id)
    JOIN
    film f USING (film_Id)
WHERE
	c.città = 'Milano'
GROUP BY
	p.film_id 
ORDER BY 
	N_proiezioni
	DESC
    LIMIT 1;



-- Trovare gli attori che hanno interpretato più personaggi in uno stesso film (+ di 1)

SELECT 
	DISTINCT a.nome
FROM 
	attore a
    JOIN
    interpreta i USING (attore_id)
GROUP BY
	a.attore_id, 
    i.film_id
HAVING
	COUNT(i.personaggio) > 1;



-- Trovare i film in cui recita un solo attore che però interpreta più personaggi

SELECT 
	f.titolo
FROM 
	film f
    JOIN
    interpreta i USING (film_id)
GROUP BY
	f.film_id
HAVING 
	COUNT(DISTINCT i.attore_id) = 1			-- Per vedere i film in cui recita un solo attore
    AND
    COUNT(i.personaggio) > 1;				-- Che però deve interpretare più di un personaggio



-- Attori italiani che non hanno mai recitato con altri attori italiani

SELECT 
	DISTINCT a.nome
FROM
	interpreta i 
    JOIN
    attore a USING (attore_id)
WHERE
	a.nazionalità = 'Italiana'
    AND
    i.film_id NOT IN (
		SELECT
			i.film_id							-- Lista in cui attori italiani hanno recitato con altri attori italiani:
		FROM									-- se non sono in questa lista vuol dire che non hanno mai recitato con altri italiani
			interpreta i
			JOIN
			attore a USING (attore_id)
		WHERE
			a.nazionalità = 'Italiana'
		GROUP BY 
			i.film_id
		HAVING
			COUNT(*) > 1
		);



-- I film di registi italiani in cui non recita nessun italiano

SELECT 
	r.nome,
    f.titolo
FROM
	film f
    JOIN
    regista r USING (regista_id)
WHERE
	r.nazionalità = 'Italiana'
    AND
	f.film_id NOT IN (
		SELECT 
			DISTINCT i.film_id								-- Togliamo tutti i film in cui ha recitato almeno un attore italiano
		FROM
			interpreta i
            JOIN
            attore a USING (attore_id)
		WHERE
			a.nazionalità = 'Italiana'
		);



-- Registi che hanno recitato in (almeno) un loro film

SELECT 
	DISTINCT r.nome
FROM
	film f
    JOIN
    regista r USING (regista_id)
	JOIN
    interpreta i USING (film_id)
    JOIN
    attore a USING (attore_id)
WHERE 
	r.nome = a.nome;



-- I registi che hanno recitato in almeno 3 loro film

SELECT 
	r.nome
FROM
	film f
    JOIN 
    regista r USING (regista_id)
	JOIN
    interpreta i USING (film_id)
    JOIN
    attore a USING (attore_id)
WHERE 
	r.nome = a.nome
GROUP BY
	r.regista_id
HAVING
	COUNT(i.film_id) >= 3;



-- Quante volte i film di Anna Lindberg sono arrivati nei cinema di Torino l'ultimo quarto del 2021

SELECT 
	COUNT(i.film_id) AS N_film
FROM
	interpreta i
	JOIN
    proiezione p USING (film_id)
    JOIN
    cinema c USING (cinema_id)
    JOIN 
	attore a USING (attore_id)
WHERE
	c.città = 'Torino'
    AND
    QUARTER(p.data) = 4
    AND
    YEAR(p.data) = 2021
    AND
    a.nome = 'Anna Lindberg';




-- Il nome del cinema che ha proiettato il numero maggiore di film per anno

WITH 
	cin AS (
		SELECT 											-- Conteggio delle proiezioni per cinema per anno
			c.cinema_id,
			c.nome_cinema AS nomecinema,
            c.città,
            YEAR(p.data) AS anno,
            COUNT(p.proiezione_id) AS conteggio
		FROM
			proiezione p
			JOIN
            cinema c USING (cinema_id)
		GROUP BY c.cinema_id, anno
        )
SELECT 
	cin1.nomecinema,
    cin1.città,
    cin1.anno,
    cin1.conteggio
FROM 
	cin cin1
	JOIN (
		SELECT											-- Selezione del conteggio massimo per anno 
			anno,
            MAX(conteggio) AS massimo
		FROM 
			cin
		GROUP BY
			anno
		) AS cin2 ON cin2.anno = cin1.anno 
		AND												-- Unione in base all'anno e al numero di proiezioni
		cin2.massimo = cin1.conteggio
ORDER BY
	anno;



-- Titoli di film che non sono mai stati proiettati a Pescara

SELECT 
	DISTINCT titolo
FROM 
	film
WHERE
	film_id NOT IN (
		SELECT 									-- Selezione di tutti film proiettati a Pescara
			DISTINCT p.film_id
		FROM 
			proiezione p
            JOIN 
            cinema c USING(cinema_id)
		WHERE
			c.città = 'Pescara'
		);