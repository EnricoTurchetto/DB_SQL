USE
	filmografia;


-- Nomi dei registi che hanno diretto nel 2022 meno film di quanti ne avevano diretti nel 2021

WITH
	a_2021
    AS (
		SELECT 										-- Conteggio dei film diretti nel 2021
			nomeregista,
            count(titolo) AS N_film
		FROM
            film 
		WHERE
			anno = 2021
		GROUP BY
			nomeregista
		),
	a_2022
    AS (
		SELECT 										-- Conteggio dei film diretti nel 2022
			nomeregista,
            count(titolo) AS N_film
		FROM
            film
		WHERE
			anno = 2022
		GROUP BY
			nomeregista
		)
SELECT 
	a21.nomeregista
FROM 
	a_2021 AS a21
	JOIN														-- Inner join perché interessano solo i registi che hanno diretto sia nel 2021 che nel 2022
	a_2022 AS a22 ON a21.nomeregista = a22.nomeregista			-- non si considerano i casi in cui i registi non hanno diretto nessun film nel 2022
WHERE
	a22.N_film < a21.N_film;									-- Confronto tra i due conteggi



-- Le date di nascita dei registi che hanno diretto film in proiezione sia a Monza sia a Treviso

SELECT
	DISTINCT datanascita
FROM 
	regista
WHERE
	nome
	IN (
    SELECT 										-- Selezione dei registi che hanno diretto film in proiezione a Monza
		DISTINCT f.nomeregista
	FROM 
		film f
		JOIN 
        proiezione p ON f.titolo = p.film
        JOIN
        cinema c USING(cinema_id)
	WHERE 
		c.città = 'Monza'
	)
    AND
    nome IN (
	SELECT 										-- Selezione dei registi che hanno diretto film in proiezione a Treviso
		DISTINCT f.nomeregista
	FROM 
		film f
		JOIN 
		proiezione p ON f.titolo = p.film
		JOIN
		cinema c USING(cinema_id)
	WHERE 
		c.città = 'Treviso'
	);
	


-- Film proiettato più volte nei cinema di Milano

SELECT
	p.film,
    COUNT(p.film) AS N_proiezioni
FROM
	proiezione p
	JOIN
    cinema c USING(cinema_id)
WHERE
	c.città = 'Milano'
GROUP BY
	p.film 
ORDER BY 
	N_proiezioni
	DESC
    LIMIT 1;



-- Trovare gli attori che hanno interpretato più personaggi in uno stesso film (+ di 1)

SELECT 
	DISTINCT attore
FROM 
	interpreta
GROUP BY
	attore, 
    film
HAVING
	COUNT(personaggio) > 1;



-- Trovare i film in cui recita un solo attore che però interpreta più personaggi

SELECT 
	film
FROM 
	interpreta
GROUP BY
	film
HAVING 
	COUNT(DISTINCT attore) = 1			-- Per vedere i film in cui recita un solo attore
    AND
    COUNT(personaggio) > 1;				-- Che però deve interpretare più di un personaggio



-- Attori italiani che non hanno mai recitato con altri attori italiani

SELECT 
	DISTINCT i.attore
FROM
	interpreta i 
    JOIN
    attore a ON i.attore = a.nome
WHERE
	a.nazionalità = 'Italiana'
    AND
    i.film NOT IN (
		SELECT
			i.film								-- Lista in cui attori italiani hanno recitato con altri attori italiani:
		FROM									-- se non sono in questa lista vuol dire che non hanno mai recitato con altri italiani
			interpreta i
			JOIN
			attore a ON i.attore = a.nome
		WHERE
			a.nazionalità = 'Italiana'
		GROUP BY 
			i.film
		HAVING
			COUNT(*) > 1
		);



-- I film di registi italiani in cui non recita nessun italiano

SELECT 
	f.nomeregista,
    f.titolo
FROM
	film f
    JOIN
    regista r ON f.nomeregista = r.nome
WHERE
	r.nazionalità = 'Italiana'
    AND
	f.titolo NOT IN (
		SELECT 
			i.film								-- Togliamo tutti i film in cui ha recitato almeno un attore italiano
		FROM
			interpreta i
            JOIN
            attore a ON i.attore = a.nome
		WHERE
			a.nazionalità = 'Italiana'
		);



-- Registi che hanno recitato in (almeno) un loro film

SELECT 
	DISTINCT f.nomeregista
FROM
	film f
	JOIN
    interpreta i ON f.titolo = i.film
WHERE 
	f.nomeregista = i.attore;



-- I registi che hanno recitato in almeno 3 loro film

SELECT 
	f.nomeregista
FROM
	film f
	JOIN
    interpreta i ON f.titolo = i.film
WHERE 
	f.nomeregista = i.attore
GROUP BY
	f.nomeregista
HAVING
	COUNT(i.film) >= 3;



-- Quante volte i film di Anna Lindberg sono arrivati nei cinema di Torino l'ultimo quarto del 2021

SELECT 
	COUNT(i.film)
FROM
	interpreta i
	JOIN
    proiezione p ON i.film = p.film
    JOIN
    cinema c USING(cinema_id)
WHERE
	c.città = 'Torino'
    AND
    QUARTER(p.data) = 4
    AND
    YEAR(p.data) = 2021
    AND
    i.attore = 'Anna Lindberg';




-- Il nome del cinema che ha proiettato il numero maggiore di film per anno

WITH 
	cin AS (
		SELECT 											-- Conteggio delle proiezioni per cinema per anno
			c.cinema_id,
			c.nome_cinema AS nomecinema,
            c.città,
            YEAR(p.data) AS anno,
            COUNT(p.proiezione_id) AS conteggio
		FROM
			proiezione p
			JOIN
            cinema c USING(cinema_id)
		GROUP BY c.cinema_id, anno
        )
SELECT 
	cin1.nomecinema,
    cin1.città,
    cin1.anno,
    cin1.conteggio
FROM 
	cin cin1
	JOIN (
		SELECT											-- Selezione del conteggio massimo per anno 
			anno,
            MAX(conteggio) AS massimo
		FROM 
			cin
		GROUP BY
			anno
		) AS cin2 ON cin2.anno = cin1.anno 
		AND												-- Unione in base all'anno e al numero di proiezioni
		cin2.massimo = cin1.conteggio
ORDER BY
	anno;



-- Titoli di film che non sono mai stati proiettati a Pescara

SELECT 
	DISTINCT film
FROM 
	proiezione
WHERE
	film NOT IN (
		SELECT 									-- Selezione di tutti film proiettati a Pescara
			p.film
		FROM 
			proiezione p
            JOIN 
            cinema c USING(cinema_id)
		WHERE
			c.città = 'Pescara'
		);