USE 
	chinook;

-- Recuperate tutte le tracce che abbiano come genere “Pop” o “Rock”
SELECT 
	t.name,
    g.name
FROM 
	track t
    JOIN genre g USING (genreid)
WHERE 
	g.name = "Pop"
    OR
    g.name = "Rock";


-- Elencate tutti gli artisti e/o gli album che inizino con la lettera “A”
SELECT 
	a.name, 
    al.title 
FROM 
	artist a 
	JOIN album al USING (artistid)
WHERE 
	a.name LIKE "A%"
	OR 
    al.title LIKE "A%";
    

-- Elencate tutte le tracce che hanno come genere “Jazz” o che durano meno di 3 minuti
SELECT 
	t.name,
    g.name,
    (t.milliseconds/60000) AS Duration
FROM 
	track t
    JOIN genre g USING (genreid)
WHERE 
	g.name = "Jazz"
    OR 
    t.milliseconds < 180000;


-- Recuperate tutte le tracce più lunghe della durata media
SELECT 
	name,
    milliseconds
FROM 
	track
WHERE 
	milliseconds >= 
		(SELECT 
			AVG(milliseconds)
		FROM 
			track
		);


-- Individuate i generi che hanno tracce con una durata media maggiore di 4 minuti
SELECT 
	g.name,
    AVG(t.milliseconds/60000) AS avg_duration
FROM 
	track t
    JOIN genre g USING (genreid)
GROUP BY
	g.name
HAVING
	avg_duration > 4;


-- Individuate gli artisti che hanno rilasciato più di un album
SELECT 
	a.name AS artist_name,
    COUNT(al.albumid) AS n_album
FROM 
	artist a
    JOIN album al USING (artistid)
GROUP BY 
	artist_name
HAVING 
	n_album > 1;


-- Trovate la traccia più lunga in ogni album
SELECT
	al.title AS album_title,
	t.name AS song_name,
    t.milliseconds
FROM 
	track t 
    JOIN album al USING (albumid)
    JOIN (SELECT
		albumid AS al_id,
		MAX(milliseconds) AS milsec
		FROM 
			track
		GROUP BY
			albumid
		) ams ON 
			t.albumid = ams.al_id
            AND 
            t.milliseconds = ams.milsec;


-- Individuate la durata media delle tracce per ogni album
SELECT 
	al.title AS album_title,
    AVG(t.milliseconds)/60000 AS average_duration
FROM 
    track t
    JOIN album al USING (albumid)
GROUP BY 
	album_title;


-- Individuate gli album che hanno più di 20 tracce e mostrate il nome dell’album e il numero di tracce in esso contenute
SELECT 
	al.title AS album_title,
    COUNT(t.trackid) AS n_track
FROM 
	track t
	JOIN album al USING (albumid)
GROUP BY
	album_title
HAVING 
	n_track > 20
ORDER BY
	n_track;


-- Recuperate il nome di tutte le tracce, del genere associato e della tipologia di media
SELECT
	t.name,
    g.name,
    mt.name
FROM 
	track t
    JOIN genre g USING (genreid)
    JOIN mediatype mt USING (mediatypeid);


-- Recuperate il nome di tutti gli artisti che hanno almeno un album nel database. Esistono artisti senza album nel database?
SELECT 
	DISTINCT a.name AS artist_name
FROM 
	artist a
    JOIN album al USING (artistid);

SELECT 
	a.name AS artist_name,
    al.title AS album_title
FROM 
	artist a
    LEFT JOIN album al USING (artistid)
WHERE 
	al.title IS NULL;


-- Elencate il numero di tracce per ogni genere in ordine discendente, escludendo quei generi che hanno meno di 10 tracce
SELECT 
	g.name AS genre_name,
    COUNT(t.trackid) AS n_track
FROM 
	track t 
    JOIN genre g USING (genreid)
GROUP BY 
	genre_name
HAVING
	n_track >= 10
ORDER BY
	n_track
	DESC;


-- Trovate le tre canzoni più costose
SELECT 
	*
FROM 
	track
ORDER BY
	unitprice
	DESC
    LIMIT 3;


-- Elencate gli artisti che hanno canzoni più lunghe di 6 minuti
SELECT 
	DISTINCT a.name
FROM 
	track t
	JOIN album al USING (albumid)
	JOIN artist a USING (artistid)
WHERE 
	t.milliseconds >180000;


-- Elencate tutte le canzoni con la parola “Love” nel titolo, ordinandole alfabeticamente prima per genere e poi per nome
SELECT 
    g.name,
    t.name
FROM 
	track t
	JOIN genre g USING (genreid)
WHERE
    t.name LIKE "%love%"
ORDER BY
	g.name,
    t.name;
    

-- Trovate il costo medio per ogni tipologia di media.
SELECT 
	mt.name,
    AVG(t.unitprice)
FROM 
	track t
	JOIN mediatype mt USING (mediatypeid)
GROUP BY
	mt.name;


-- Individuate il genere con più tracce
SELECT 
	g.name,
    COUNT(t.trackid) AS n_track
FROM 
	track t
    JOIN genre g USING (genreid)
GROUP BY
	g.name
ORDER BY
	n_track
	DESC
    LIMIT 1;


-- Trovate gli artisti che hanno lo stesso numero di album dei AC/DC
SELECT
	a.name,
	COUNT(al.albumid) AS n_album
FROM
	artist a
	JOIN album al USING (artistid)
GROUP BY 
	a.name
HAVING 
	n_album = (
		SELECT 
            COUNT(al.albumid)
		FROM 
			artist a
			JOIN album al USING (artistid)
		GROUP BY
			a.name
		HAVING
			a.name = "AC/DC"
		);


-- Trovate l’artista con l’album più costoso
SELECT
	a.name,
    al.title,
    SUM(t.unitprice) AS album_cost
FROM 
	track t
    JOIN album al USING (albumid)
    JOIN artist a USING (artistid)
GROUP BY
	al.title,
    a.name
ORDER BY 
	album_cost
    DESC
    LIMIT 1;