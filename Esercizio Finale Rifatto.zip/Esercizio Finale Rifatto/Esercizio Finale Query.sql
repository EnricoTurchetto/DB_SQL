USE 
	toysgroup;

-- Verificare che i campi definiti come PK siano univoci

SELECT 
	COUNT(DISTINCT categoria_id),
	COUNT(categoria_id)
FROM 
	categoria;
    
SELECT 
	COUNT(DISTINCT prodotto_id),
	COUNT(prodotto_id)
FROM 
    prodotti;

SELECT 
	COUNT(DISTINCT regione_id),
	COUNT(regione_id)
FROM 
    regioni;

SELECT 
	COUNT(DISTINCT stato_id),
	COUNT(stato_id)
FROM 
    stati;

SELECT 
	COUNT(DISTINCT cliente_id),
	COUNT(cliente_id)
FROM 
    clienti;
    
SELECT 
	COUNT(DISTINCT dettaglio_id),
	COUNT(dettaglio_id)
FROM 
    dettaglio_ordine;

SELECT 
	COUNT(DISTINCT transizione_id),
	COUNT(transizione_id)
FROM 
    transizioni;



-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT 
	p.nome,
	YEAR(d.data_ordine) AS Anno,
    SUM(t.importo) AS Totale_fatturazione 
FROM 
    dettaglio_ordine d
	JOIN prodotti p USING(prodotto_id)
	JOIN transizioni t USING(dettaglio_id)
GROUP BY 
	p.nome, 
    Anno
ORDER BY 
	p.nome;



-- Esporre il fatturato totale per stato per anno

SELECT 
	s.nome,
	YEAR(d.data_ordine) AS Anno,
    SUM(t.importo) AS Totale_fatturazione 
FROM 
	dettaglio_ordine d
	JOIN transizioni t USING(dettaglio_id)
	JOIN clienti c USING(cliente_id)
	JOIN stati s USING(stato_id)
GROUP BY 
	s.nome, 
    Anno
ORDER BY 
	s.nome;



-- Ordina il risultato precedente per data e per fatturato decrescente

SELECT 
	s.nome,
	YEAR(d.data_ordine) AS Anno,
    SUM(t.importo) AS Totale_fatturazione 
FROM 
    dettaglio_ordine d
	JOIN transizioni t USING(dettaglio_id)
	JOIN clienti c USING(cliente_id)
	JOIN stati s USING(stato_id)
GROUP BY 
	s.nome, 
    Anno
ORDER BY 
	Anno 
	DESC, 
	Totale_fatturazione 
	DESC;



-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT 
	c.nome,
	SUM(d.quantità) AS N_articoli_venduti			-- Cateogoria maggiormente richiesta per numero 
FROM 												-- di prodotti venduti
    dettaglio_ordine d
	JOIN prodotti p USING(prodotto_id)
	JOIN categoria c USING(categoria_id)
GROUP BY 
	c.nome
ORDER BY 
	N_articoli_venduti 
	DESC 
    LIMIT 1;

SELECT 
	c.nome,
	SUM(t.importo) AS Fatturazione_articoli_venduti
FROM 
    dettaglio_ordine d									-- Da notare come la categoria maggiormente richiesta non sia 
	JOIN prodotti p USING(prodotto_id)					-- quella dal maggior fatturato
	JOIN categoria c USING(categoria_id)
	JOIN transizioni t USING(dettaglio_id)
GROUP BY 
	c.nome
ORDER BY 
	Fatturazione_articoli_venduti 
    DESC;



-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti

SELECT 
	p.nome
FROM 
    dettaglio_ordine d
	RIGHT JOIN prodotti p USING(prodotto_id)
WHERE 
	d.quantità IS NULL;

SELECT 
	nome 
FROM 
    prodotti
WHERE 
	prodotto_id NOT IN (
		SELECT 
			DISTINCT prodotto_id 
		FROM 
			dettaglio_ordine
		);
        
SELECT 
	COUNT(DISTINCT p.prodotto_id) AS N_prodotti,				-- Verifica del numero di prodotti invenduti
	COUNT(DISTINCT d.prodotto_id) AS N_prodotti_venduti,
    COUNT(DISTINCT p.prodotto_id) - COUNT(DISTINCT d.prodotto_id) AS N_prodotti_invenduti
FROM 
    dettaglio_ordine d
	RIGHT JOIN prodotti p USING(prodotto_id);



-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)

SELECT 
	p.nome,
	MAX(d.data_ordine) AS Ultima_data_vendita
FROM 
    dettaglio_ordine d 
	JOIN prodotti p USING(prodotto_id)
GROUP BY 
	p.nome
ORDER BY 
	p.nome;



/*
BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
in base alla condizione che siano passati più di 270 giorni dalla data vendita o meno (>270 -> True, <= 270 -> False)
*/

SELECT 
	d.dettaglio_id,
	d.data_ordine,
    p.nome AS nome_prodotto,
    c.nome AS nome_categoria,
    s.nome AS nome_stato,
    r.nome AS nome_regione,
    CASE 
		WHEN DATEDIFF(CURDATE(), d.data_ordine) <= 270 THEN "False" 
		ELSE "True" 
        END 
        AS Passati_270_giorni
FROM 
    dettaglio_ordine d 
	JOIN prodotti p USING(prodotto_id)
	JOIN categoria c USING(categoria_id)
	JOIN clienti cl USING(cliente_id)
	JOIN stati s USING(stato_id)
	JOIN regioni r USING(regione_id);
