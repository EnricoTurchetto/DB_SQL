DROP DATABASE IF EXISTS toysgroup;

-- Crezione del DataBase

CREATE DATABASE toysgroup;

USE toysgroup;


-- Creazione delle tabelle

-- Crezione tabella Categoria

CREATE TABLE Categoria (
	categoria_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nome VARCHAR(50) NOT NULL
    );


-- Crezione tabella Prodotti

CREATE TABLE Prodotti (
	prodotto_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nome VARCHAR(50) NOT NULL,
    categoria_id INT NOT NULL,
    prezzo DECIMAL (10, 2) NOT NULL,
    FOREIGN KEY (categoria_id) REFERENCES Categoria (categoria_id)
		ON DELETE RESTRICT ON UPDATE CASCADE
    );


-- Crezione tabella Regioni

CREATE TABLE Regioni (
	regione_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nome VARCHAR(50) NOT NULL
    );
    

-- Crezione tabella Stati

CREATE TABLE Stati (
	stato_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nome VARCHAR(50) NOT NULL,
    regione_id INT NOT NULL,
    FOREIGN KEY (regione_id) REFERENCES Regioni (regione_id)
		ON DELETE RESTRICT ON UPDATE CASCADE
    );
    

-- Crezione tabella Clienti

CREATE TABLE Clienti (
	cliente_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,
    stato_id INT NOT NULL,
    FOREIGN KEY (stato_id) REFERENCES Stati (stato_id)
		ON DELETE RESTRICT ON UPDATE CASCADE
    );
    

-- Crezione tabella Dettaglio_ordine

 CREATE TABLE Dettaglio_ordine (
	dettaglio_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    data_ordine DATE NOT NULL,
    prodotto_id INT NOT NULL,
    quantità INT NOT NULL,
    cliente_id INT NOT NULL,
    FOREIGN KEY (prodotto_id) REFERENCES Prodotti (prodotto_id)
		ON DELETE RESTRICT ON UPDATE CASCADE,
	FOREIGN KEY (cliente_id) REFERENCES Clienti (cliente_id)
		ON DELETE RESTRICT ON UPDATE CASCADE
	);



-- INSERIMENTO DATI


-- Inseriemnto dati nella tabella Categoria

INSERT INTO Categoria (nome) VALUES
	("Animali"),
    ("Avventura"),
    ("Azione"),
    ("Carte"), 
    ("Giochi Da Tavolo"),
    ("Puzzle"),
    ("Sport"),
    ("Strategia");


-- Inseriemnto dati nella tabella Prodotti

INSERT INTO Prodotti (nome, categoria_id, prezzo) VALUES
	('Rapid Fury', 3, 25.99),
	('Shadow Assault', 2, 53.99),
	('Nebula Blitz', 4, 47.99),
	('Legends of Lumina', 2, 57.99),
	('Mystic Quest Chronicles', 3, 30.99),
	('Tales of Terra', 3, 58.99),
	('Creature Safari Adventure', 1, 59.99),
	('Zoological Odyssey', 1, 52.99),
	('Card Clash Royale', 4, 57.99),
	('Ace Alliance', 6, 29.99),
	('Gameboard Gala', 5, 53.99),
	('Dice Dynasty', 5, 58.99),
	('Mosaic Masterpiece', 6, 46.99),
	('Strategic Siege', 8, 51.99),
	('Tactical Triumph', 8, 49.99),
	('Sport Slam', 7, 36.99),
	('Athletic Arena', 7, 55.99);


-- Inseriemnto dati nella tabella Regioni

INSERT INTO Regioni (nome) VALUES
	('Europa Settentrionale'),				-- Le suddivisioni europee sono state create 
    ('Europa Occidentale'),					-- seguendo il Geoschema delle Nazioni Unite
    ('Europa Orientale'),
    ('Europa Meridionale'),
    ('Nord America'),
    ('Asia');


-- Inseriemnto dati nella tabella Stati

INSERT INTO Stati (nome, regione_id) VALUES
	('Regno Unito', 1),
    ('Danimarca', 1),
    ('Svezia', 1),
    ('Norvegia', 1),
    ('Francia', 2),
    ('Germania', 2),
    ('Belgio', 2),
    ('Polonia', 3),
    ('Romania', 3),
    ('Italia', 4), 
    ('Spagna', 4),
    ('Grecia', 4),
    ('Canada', 5),
    ('USA', 5),
    ('Giappone', 6);


-- Inseriemnto dati nella tabella Clienti

INSERT INTO Clienti (nome, cognome, stato_id) VALUES
	('Marco', 'Bianchi', 10),
	('Simona', 'Rossi', 10),
	('Luigi', 'Esposito', 10),
	('Anna', 'Ferrari', 10),
	('Davide', 'Conti', 10),
	('Pierre', 'Dubois', 5),
	('Marie', 'Lefèvre', 5),
	('Julien', 'Martin', 5),
	('Sophie', 'Bernard', 5),
	('Antoine', 'Laurent', 5),
	('John', 'Smith', 1),
	('Emma', 'Johnson', 1),
	('Michael', 'Brown', 1),
	('Olivia', 'Williams', 1),
	('James', 'Taylor', 1),
	('Charlotte', 'Davies', 1),
	('William', 'Evans', 1),
	('Emily', 'Clarke', 13),
	('Thomas', 'Wilson', 13),
	('Sarah', 'Miller', 13),
	('George', 'Harris', 13),
	('Lucy', 'Thompson', 14),
	('Daniel', 'Scott', 14),
	('Jessica', 'Moore', 14),
	('Matthew', 'Cooper', 14),
	('José', 'López', 11),
	('Carmen', 'González', 11),
	('Pablo', 'Pérez', 11),
	('Isabel', 'Sánchez', 11),
	('Diego', 'Hernández', 11),
	('Nikos', 'Papadopoulos', 12),
	('Maria', 'Georgiou', 12),
	('Dimitris', 'Konstantinou', 12),
	('Eleni', 'Nikolaou', 12),
	('Kostas', 'Vasilakis', 12),
	('Haruto', 'Tanaka', 15),
	('Yuki', 'Nakamura', 15),
	('Sakura', 'Yamamoto', 15),
	('Riku', 'Sato', 15),
	('Aiko', 'Suzuki', 15),
	('Lars', 'Christensen', 2),
	('Emma', 'Hansen', 2),
	('Erik', 'Johansson', 3),
	('Anna', 'Lindberg', 3),
	('Anders', 'Olsen', 4),
	('Lukas', 'Müller', 6),
	('Anna', 'Schmidt', 6),
	('Felix', 'Bauer', 6),
	('Sophie', 'Wagner', 6),
	('Max', 'Becker', 6),
	('Olivier', 'Dupont', 7),
	('Andrzej', 'Kowalski', 8),
	('Maria', 'Nowak', 8),
	('Alexandru', 'Popescu', 9);


-- Inseriemnto dati nella tabella Dettaglio_ordine

INSERT INTO Dettaglio_ordine (data_ordine, prodotto_id, quantità, cliente_id) VALUES
	('2020-02-21', 5, 1, 1),
('2020-02-22', 16, 2, 2),
('2020-03-04', 4, 1, 3),
('2020-03-11', 17, 1, 4),
('2020-04-23', 5, 1, 5),
('2020-04-23', 14, 1, 6),
('2020-04-23', 16, 2, 7),
('2020-06-11', 8, 2, 8),
('2020-06-14', 2, 2, 9),
('2020-07-06', 12, 3, 10),
('2020-07-07', 1, 3, 11),
('2020-07-18', 16, 2, 12),
('2020-09-29', 11, 1, 13),
('2020-10-05', 8, 2, 14),
('2020-11-12', 12, 3, 15),
('2021-01-01', 15, 2, 16),
('2021-01-17', 2, 1, 17),
('2021-01-29', 1, 2, 18),
('2021-02-05', 2, 1, 19),
('2021-02-08', 7, 2, 20),
('2021-03-24', 3, 3, 21),
('2021-04-09', 14, 2, 22),
('2021-04-24', 1, 2, 23),
('2021-05-04', 8, 1, 24),
('2021-05-12', 2, 2, 25),
('2021-05-25', 14, 2, 26),
('2021-06-05', 9, 2, 27),
('2021-06-08', 15, 2, 28),
('2021-06-20', 1, 1, 29),
('2021-06-23', 8, 1, 30),
('2021-07-05', 4, 1, 31),
('2021-08-06', 17, 3, 32),
('2021-08-24', 17, 1, 33),
('2021-09-19', 7, 2, 34),
('2021-10-04', 14, 3, 35),
('2021-10-10', 17, 1, 36),
('2021-10-17', 14, 2, 37),
('2021-11-14', 17, 2, 38),
('2021-12-03', 9, 1, 39),
('2021-12-27', 3, 1, 40),
('2022-01-01', 9, 1, 41),
('2022-01-11', 5, 1, 42),
('2022-01-23', 8, 2, 43),
('2022-01-24', 14, 1, 44),
('2022-03-08', 13, 3, 45),
('2022-04-18', 5, 1, 46),
('2022-04-27', 16, 1, 47),
('2022-04-29', 5, 1, 48),
('2022-05-17', 5, 1, 49),
('2022-05-22', 2, 3, 50),
('2022-06-12', 7, 2, 51),
('2022-07-03', 1, 1, 52),
('2022-07-27', 16, 1, 53),
('2022-08-19', 12, 3, 54),
('2022-10-13', 1, 3, 48),
('2022-10-23', 2, 1, 41),
('2022-11-24', 16, 1, 34),
('2022-12-01', 4, 2, 10),
('2022-12-02', 16, 1, 20),
('2022-12-07', 5, 2, 47),
('2022-12-25', 17, 1, 42),
('2023-01-14', 9, 2, 21),
('2023-01-15', 2, 1, 2),
('2023-01-19', 9, 1, 3),
('2023-01-27', 7, 3, 25),
('2023-02-18', 5, 1, 19),
('2023-02-24', 5, 2, 39),
('2023-03-19', 6, 2, 41),
('2023-03-21', 1, 1, 35),
('2023-04-18', 3, 2, 48),
('2023-04-29', 6, 3, 15),
('2023-05-18', 13, 1, 23),
('2023-06-02', 7, 3, 53),
('2023-06-07', 1, 2, 5),
('2023-06-24', 16, 2, 31),
('2023-06-30', 7, 1, 23),
('2023-07-01', 14, 2, 52),
('2023-08-15', 2, 2, 27),
('2023-09-25', 3, 1, 46),
('2023-10-12', 2, 2, 14),
('2023-10-21', 6, 2, 43),
('2023-10-24', 17, 1, 49),
('2023-11-04', 6, 1, 32),
('2023-11-13', 4, 2, 22),
('2023-11-16', 7, 2, 10),
('2023-11-22', 8, 3, 6),
('2023-12-17', 11, 2, 44),
('2024-01-15', 1, 2, 27),
('2024-02-10', 17, 1, 34),
('2024-03-12', 14, 2, 30),
('2024-04-06', 5, 2, 19),
('2024-05-09', 8, 2, 32),
('2024-05-14', 2, 1, 14),
('2024-05-17', 17, 2, 53),
('2024-06-17', 7, 2, 25),
('2024-07-13', 16, 1, 35),
('2024-07-13', 9, 1, 42),
('2024-07-31', 15, 1, 25),
('2024-08-07', 11, 1, 30),
('2024-08-14', 6, 2, 36),
('2024-08-22', 5, 1, 21),
('2024-08-24', 4, 1, 50),
('2024-08-28', 12, 2, 8);



-- Creazione della tabella Transizioni

CREATE TABLE Transizioni (
	transizione_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    dettaglio_id INT,
    importo DECIMAL (10, 2),
    FOREIGN KEY (dettaglio_id) REFERENCES Dettaglio_ordine (dettaglio_id)
		ON DELETE RESTRICT ON UPDATE CASCADE
	);
    
    
-- Inserimento dati nella tabella Transizioni

INSERT INTO Transizioni (dettaglio_id, importo) 
	SELECT d.dettaglio_id,
		d.quantità * p.prezzo
        FROM Dettaglio_ordine d
	JOIN Prodotti p USING(prodotto_id);
