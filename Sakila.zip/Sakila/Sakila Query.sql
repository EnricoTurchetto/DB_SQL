USE 
	sakila;


/*
Effettuate un’esplorazione preliminare del database. Di cosa si tratta? Quante e quali tabelle contiene? 
Fate in modo di avere un’idea abbastanza chiara riguardo a con cosa state lavorando.
*/

SHOW TABLES;

SELECT 
	* 
FROM 
	actor;

SELECT 
	*
FROM 
	category;

SELECT 
	* 
FROM 
	film;

SELECT 
	AVG(rental_duration), 
	AVG(rental_rate), 
	AVG(length),
	AVG(replacement_cost)
FROM 
	film;

SELECT 
	DISTINCT rating 
FROM 
    film;

SELECT 
	* 
FROM 
    payment;

SELECT 
	AVG(amount) 
FROM 
    payment;

SELECT 
	* 
FROM 
    rental;

SELECT 
	MIN(rental_date), 
	MAX(rental_date) 
FROM 
    rental;



-- Scoprite quanti clienti si sono registrati nel 2006
SELECT 
	first_name,
	last_name,
    create_date
FROM 
    customer
WHERE 
	YEAR(create_date) = 2006;



-- Trovate il numero totale di noleggi effettuati il giorno 09/07/2005
SELECT 
	COUNT(rental_id)
FROM 
    rental
WHERE 
	DATE(rental_date) = '2005-07-09';



-- Elencate tutti i film noleggiati nell’ultima settimana e tutte le informazioni legate al cliente che li ha noleggiati
SELECT 
	r.rental_date,
	f.title AS Film_title,
	c.customer_id,
	CONCAT(c.first_name, " ", c.last_name) AS Customer_name,
    c.email,
    c.address_id,
    c.active,
    c.create_date,
    c.last_update
FROM 
	customer c
	JOIN rental r USING(customer_id)
	JOIN inventory i USING(inventory_id)
	JOIN film f USING(film_id)
WHERE 
	DATE(r.rental_date) >= (
		SELECT 
			SUBDATE(MAX(rental_date), INTERVAL 1 WEEK) 
		FROM 
			rental);



-- Calcolate la durata media del noleggio per ogni categoria di film
SELECT 
	cat.name AS Category_name,
	AVG(
		DATEDIFF(r.return_date, r.rental_date)
        ) AS Average_rental
FROM 
	rental r
	JOIN inventory i USING(inventory_id)
	JOIN film f USING(film_id)
	JOIN film_category fc USING(film_id)
	JOIN category cat USING (category_id)
GROUP BY 
	Category_name
ORDER BY 
	Average_rental 
    DESC;



-- Trovate la durata del noleggio più lungo
SELECT
	DATEDIFF(return_date, rental_date) AS Rental_length
FROM 
    rental 
ORDER BY 
	Rental_length 
    DESC 
    LIMIT 1;



-- Identificate tutti i clienti che non hanno effettuato nessun noleggio a gennaio 2006.
SELECT 
	*
FROM 
    customer
WHERE 
	customer_id NOT IN (
		SELECT 
			customer_id 
		FROM 
            rental
		WHERE 
			YEAR(rental_date) = 2006
    );



-- Elencate tutti i film che sono stati noleggiati più di 10 volte nel penultimo quarto del 2005
SELECT 
	f.title,
	COUNT(r.rental_id) AS N_rental
FROM 
    rental r
	JOIN inventory i USING(inventory_id)
	JOIN film f USING(film_id)
WHERE 
	YEAR(r.rental_date) = 2005
	AND 
    QUARTER(r.rental_date) = 3
GROUP BY 
	f.title
HAVING 
	N_rental >= 10
ORDER BY 
	N_rental 
    DESC;



-- Trovate il numero totale di noleggi effettuati il giorno 14/2/2006
SELECT 
	DISTINCT DATE(rental_date) AS Date_rental,
	COUNT(rental_id) AS N_rental
FROM 
    rental
WHERE 
	DATE(rental_date) = '2006-02-14'
GROUP BY 
	Date_rental;



-- Calcolate la somma degli incassi generati nei weekend (sabato e domenica)
SELECT 
	SUM(amount) AS Total_revenue
FROM 
	payment
WHERE 
	WEEKDAY(payment_date) >= 5;



-- Individuate il cliente che ha speso di più in noleggi
SELECT 
	CONCAT(c.first_name, " ", c.last_name) AS Client_name,
	SUM(p.amount) AS Total_rental_cost
FROM 
    rental r
	JOIN customer c USING (customer_id)
	JOIN payment p USING (rental_id)
GROUP BY 
	Client_name
ORDER BY 
	Total_rental_cost 
	DESC
	LIMIT 1;



-- Elencate i 5 film con la maggior durata media di noleggio
SELECT 
	f.title,
	AVG(
		DATEDIFF(r.return_date, r.rental_date)
        ) AS Average_length_rental
FROM 
    rental r
	JOIN inventory i USING(inventory_id)
	JOIN film f USING(film_id)
GROUP BY 
	f.title
ORDER BY 
	Average_length_rental
	DESC
    LIMIT 5;



-- Individuate il numero di noleggi per ogni mese del 2005
SELECT 
	MONTHNAME(rental_date) AS Month_name,
	COUNT(rental_id) AS Total_rental
FROM 
    rental
WHERE 
	YEAR(rental_date) = 2005
GROUP BY 
	Month_name;



-- Trovate i film che sono stati noleggiati almeno due volte lo stesso giorno
SELECT 
	DISTINCT f.title 
FROM 
    film f
	JOIN (
		SELECT 
			i.film_id AS id_film,
			DATE(r.rental_date),
			COUNT(i.film_id)
		FROM 
            rental r
			JOIN inventory i USING(inventory_id)
		GROUP BY 
			DATE(r.rental_date), i.film_id
		HAVING 
			COUNT(i.film_id)>1
		) AS c ON f.film_id = c.id_film;


WITH 
	counting AS (
		SELECT 
			i.film_id AS id_film,
			DATE(r.rental_date),
			COUNT(i.film_id)
		FROM 
			rental r
			JOIN inventory i USING(inventory_id)
		GROUP BY 
			DATE(r.rental_date), i.film_id
		HAVING 
			COUNT(i.film_id)>1
    )
SELECT 
	DISTINCT f.title 
FROM 
    film f
	JOIN counting c ON f.film_id = c.id_film;


-- Calcolate il tempo medio di noleggio
WITH 														-- Per trovare il tempo medio di noleggio totale
	Avg_rental AS (
		SELECT 
			ROUND(
				AVG(
					DATEDIFF(return_date, rental_date)
					), 2
				) AS total_rental_avg
		FROM 
			rental
		),
    avg_film AS (											-- Per trovare il tempo medio di noleggio per ogni film
		SELECT 
			DISTINCT f.title AS film_title,
			ROUND(
				AVG(
					DATEDIFF(r.return_date, r.rental_date)
					), 2
				) AS film_avg_rental
		FROM 
            rental r
            JOIN inventory i USING(inventory_id)
            JOIN film f USING(film_id)
		GROUP BY 
			f.title
		)
SELECT 
	film_title,
	film_avg_rental,
    total_rental_avg,
    (CASE 														-- Per capire se il tempo medio di noleggio per ogni film
		WHEN 													-- è più alto, più basso o uguale alla media totale
			film_avg_rental < total_rental_avg
		THEN
			"lower"
		WHEN
			film_avg_rental > total_rental_avg
		THEN
			"higher"
		ELSE
			"equal"
		END
        ) AS compared
FROM 
    avg_film, 
    Avg_rental
;