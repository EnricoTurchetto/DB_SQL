-- Creazione del DataBase

CREATE DATABASE ToysGroup;


USE ToysGroup;


-- Creazione delle Tabelle

-- Creazione della tabella della categoria dei giochi, chimata 'Genre'

CREATE TABLE Genre (
IDGenre INT NOT NULL,
NameGenre VARCHAR(50) NOT NULL,
PRIMARY KEY (IDGenre)
);


-- Creazione della tabella dei giochi, chiamata 'Products'

CREATE TABLE Products (
IDProduct INT NOT NULL,
NameProduct VARCHAR(50) NOT NULL,
IDGenre INT NOT NULL,
PriceEach DECIMAL(10, 2) NOT NULL,
PRIMARY KEY (IDProduct),
FOREIGN KEY (IDGenre) REFERENCES Genre (IDGenre)
);


-- Creazione della tabella delle regioni mondiali, chiamata 'Regions'

CREATE TABLE Regions (
IDRegion INT NOT NULL,
NameRegion VARCHAR(50) NOT NULL,
PRIMARY KEY (IDRegion)
);


-- Creazione della tabella degli Stati, chiamata 'Countries'

CREATE TABLE Countries (
IDCountry INT NOT NULL,
NameCountry VARCHAR(50) NOT NULL,
IDRegion INT NOT NULL,
PRIMARY KEY (IDCountry),
FOREIGN KEY (IDRegion) REFERENCES Regions (IDRegion)
);


-- Creazione delle tabella relativa alle vendite, chiamata 'Sales'

CREATE TABLE Sales (
IDSales INT NOT NULL,
IDProduct INT NOT NULL,
Quantity TINYINT,
DateSales DATE NOT NULL,
Amount DECIMAL(10,2),
IDCountry INT NOT NULL,
PRIMARY KEY (IDSales),
FOREIGN KEY (IDProduct) REFERENCES Products (IDProduct),
FOREIGN KEY (IDCountry) REFERENCES Countries (IDCountrY)
);




-- Insermiento dei Dati

-- Inserimento dei dati nella tabella 'Genre'

INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10001, 'Action');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10002, 'Adventure');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10003, 'Animals');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10004, 'Cards');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10005, 'Board Games');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10006, 'Jigsaw');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10007, 'Strategy');
INSERT INTO Genre (IDGenre, NameGenre) 
VALUES
(10008, 'Sport');


-- Inserimento dei dati nella tabella 'Products'

INSERT INTO Products (IDProduct, NameProduct, IDGenre, PriceEach) 
VALUES
(20001, 'Rapid Fury', 10001, 49.99),
(20002, 'Shadow Assault', 10001, 45.95),
(20003, 'Nebula Blitz', 10001, 32.99),
(20004, 'Legends of Lumina', 10002, 79.95),
(20005, 'Mystic Quest Chronicles', 10002, 55.60),
(20006, 'Tales of Terra', 10002, 49.99),
(20007, 'Creature Safari Adventure', 10003, 32.99),
(20008, 'Zoological Odyssey', 10003, 19.99),
(20009, 'Card Clash Royale', 10004, 9.99),
(20010, 'Ace Alliance', 10004, 14.99),
(20011, 'Gameboard Gala', 10005, 89.99),
(20012, 'Dice Dynasty', 10005, 65.99),
(20013, 'Mosaic Masterpiece', 10006, 55.60), 
(20014, 'Strategic Siege', 10007, 45.95),
(20015, 'Tactical Triumph', 10007, 49.99),
(20016, 'Sport Slam', 10008, 32.99),
(20017, 'Athletic Arena', 10008, 55.60);


-- Inserimento dei dati nella tabella 'Regions'

INSERT INTO Regions (IDRegion, NameRegion) 
VALUES
(50001, 'Europe'),
(50002, 'Asia'),
(50003, 'Africa'),
(50004, 'North America'),
(50005, 'South America'),
(50006, 'Oceania');


-- Inserimento dei dati nella tabella 'Countries'

INSERT INTO Countries (IDCountry, NameCountry, IDRegion) 
VALUES
(40001, 'Italy', 50001),
(40002, 'Germany', 50001),
(40003, 'France', 50001),
(40004, 'Spain', 50001),
(40005, 'UK', 50001),
(40006, 'Japan', 50002),
(40007, 'China', 50002),
(40008, 'USA', 50004),
(40009, 'Canada',50004),
(40010, 'Brazil', 50005),
(40011, 'Argentina', 50005);


-- Inserimento dei dati nella tabella 'Sales'

INSERT INTO Sales (IDSales, IDProduct, Quantity, DateSales, Amount, IDCountry) 
VALUES
(30001, 20006, 1, '2021-01-01', 49.99, 40001),
(30002, 20013, 2, '2021-02-02', 111.20, 40006),
(30003, 20002, 1, '2021-03-03', 45.95, 40002),
(30004, 20004, 5, '2021-04-04', 399.75, 40005),
(30005, 20013, 1, '2021-05-05', 55.60, 40004),
(30006, 20015, 1, '2021-06-06', 49.99, 40002),
(30007, 20006, 1, '2021-07-07', 49.99, 40003),
(30008, 20016, 4, '2021-08-08', 131.96, 40010),
(30009, 20004, 1, '2021-09-09', 79.95, 40008),
(30010, 20015, 1, '2021-10-10', 49.99, 40002),
(30011, 20016, 1, '2021-11-11', 32.99, 40004),
(30012, 20008, 3, '2021-12-12', 59.97, 40001),
(30013, 20004, 1, '2022-01-01', 79.95, 40011),
(30014, 20013, 1, '2022-03-03', 55.60, 40004),
(30015, 20016, 1, '2022-04-04', 32.99, 40002),
(30016, 20002, 2, '2022-05-05', 91.90, 40003),
(30017, 20006, 1, '2022-06-06', 49.99, 40006),
(30018, 20015, 2, '2022-07-07', 99.98, 40001),
(30019, 20006, 1, '2022-08-08', 49.99, 40009),
(30020, 20004, 1, '2023-01-01', 79.95, 40005),
(30021, 20013, 2, '2023-02-02', 111.20, 40007),
(30022, 20007, 1, '2023-03-03', 32.99, 40003);





/* 
1. Verificare che i campi definiti come PK siano univoci
Contando il campo definito come PK e poi contando fancendo una 'Select Distinct' dovrebbe dare lo stesso numero, 
altirmenti vorrebbe dire che è presente una PK non univoca
*/

-- Verifica che nella tabella 'Products' il campo definito come PK sia univoco

SELECT COUNT(IDProduct) as No_Products 
FROM Products;

SELECT DISTINCT COUNT(IDProduct) as No_Products 
FROM Products;



-- Verifica che nella tabella 'Genre' il campo definito come PK sia univoco

SELECT COUNT(IDGenre) AS No_Genre 
FROM Genre;

SELECT DISTINCT COUNT(IDGenre) AS No_Genre 
FROM Genre;


-- Verifica che nella tabella 'Sales' il campo definito come PK sia univoco

SELECT COUNT(IDSales) AS No_Sales 
FROM Sales;

SELECT DISTINCT COUNT(IDSales) AS No_Sales 
FROM Sales;


-- Verifica che nella tabella 'Countries' il campo definito come PK sia univoco

SELECT COUNT(IDCountry) AS No_Countries 
FROM Countries;

SELECT DISTINCT COUNT(IDCountry) AS No_Countries 
FROM Countries;


-- Verifica che nella tabella 'Regions' il campo definito come PK sia univoco

SELECT COUNT(IDRegion) AS No_Regions 
FROM Regions;

SELECT DISTINCT COUNT(IDRegion) AS No_Regions 
FROM Regions;




-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT p.NameProduct, SUM(s.Amount) AS Revenue, YEAR(s.DateSales) as Year 
FROM Products p
JOIN Sales s USING(IDProduct)
GROUP BY p.NameProduct, Year
ORDER BY p.NameProduct;



-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

SELECT DISTINCT c.NameCountry, SUM(s.Amount) AS Revenue, YEAR(s.DateSales) as Year 
FROM Products p
JOIN Sales s USING(IDProduct)
JOIN Countries c USING(IDCountry)
GROUP BY c.NameCountry, Year
ORDER BY Year, Revenue DESC;



-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT g.NameGenre, SUM(s.Quantity) AS TotQuantity 
FROM Sales s
JOIN Products p USING(IDProduct)
JOIN Genre g USING(IDGenre)
GROUP BY g.NameGenre
ORDER BY TotQuantity DESC
LIMIT 1;



-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti

SELECT NameProduct 
FROM Products 
WHERE IDProduct NOT IN (
	SELECT DISTINCT IDProduct FROM Sales
    );

SELECT p.NameProduct, SUM(s.Quantity) AS Quantity 
FROM Products p
LEFT JOIN Sales s USING(IDProduct)
GROUP BY p.NameProduct
HAVING Quantity IS NULL;



-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)

SELECT DISTINCT p.NameProduct, MAX(DATE(s.DateSales)) AS LeastDate 
FROM Products p
JOIN Sales s USING(IDProduct)
GROUP BY p.NameProduct;